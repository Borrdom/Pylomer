from .python_module import crank,BH_Model,lnai,TgGT
from .rust_module.rust import is_prime,ode_example
